from typing import Any


class LLM:
    kwargs: dict[str, Any]

    def run(self):
        pass
