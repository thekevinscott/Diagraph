from typing import Callable, Any

Fn = Callable

Result = Any
